Welcome To Glitch!
==================

Edit this file to tell people about your project.

To view your project click the "Show Live" button in the upper left of the screen.

We hope you enjoy our friendly and welcoming community. If you have any problems or questions feel free to reach out to us through our [support forum](https://support.glitch.com/).

Thank you, and have a great day!
